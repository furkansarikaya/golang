package demo

func Topla(x, y) int {
	return x + y
}
